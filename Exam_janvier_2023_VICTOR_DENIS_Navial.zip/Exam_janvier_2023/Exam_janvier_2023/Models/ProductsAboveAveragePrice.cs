﻿using System;
using System.Collections.Generic;

namespace Exam_janvier_2023.Models;

public partial class ProductsAboveAveragePrice
{
    public string ProductName { get; set; } = null!;

    public decimal? UnitPrice { get; set; }
}
